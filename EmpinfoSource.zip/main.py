class Employee:
  numemp = 0
  def __init__(self,first,last,dept):
    self.first = first
    self.last = last
    self.dept = dept
    self.email = first[0] + last + "@warren.edu"
    Employee.numemp +=1
  def fullname(self):
    return f"{self.last}, {self.first}"
class Adjunct(Employee):
  def __init__(self, first, last, dept, rank):
      super().__init__(first, last, dept)
      self.rank = rank
      self.email = first + "." + last + "@warren.edu"
Dept = "Academics"
JA = "Adjunct"
SA = "Senior Adjunct"



emp1 = Employee("Robert","Smith","Faculty")
emp2 = Employee("Adrian","Anderson","Academics")
emp3 = Employee("Rick","Richards","Office")
emp4 = Adjunct("Hi","Bye",Dept, SA)
print(emp1.email.lower())
print(emp1.dept.lower())
print(emp1.fullname())
#
print(emp2.email.lower())
print(emp2.dept.lower())
print(emp2.fullname())
#
print(emp3.email.lower())
print(emp3.dept.lower())
print(emp3.fullname())
print("Total Employees:",Employee.numemp)
#
print(emp4.email.lower())
print(emp4.dept.lower())
print(emp4.fullname())
